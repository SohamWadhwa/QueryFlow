import requests
from config.config import settings

API_URL = settings.API_URL
MODEL_NAME = settings.MODEL_NAME

# Generous but bounded: local LLMs can be slow, but an infinite wait means
# one hung Ollama call blocks the next generate forever.
OLLAMA_TIMEOUT = 30  # seconds


def call_model(prompt: str) -> str:
    try:
        res = requests.post(
            API_URL,
            json={
                "model": MODEL_NAME,
                "prompt": prompt,
                "stream": False,
            },
            timeout=OLLAMA_TIMEOUT,
        )
    except requests.exceptions.Timeout:
        raise Exception("Ollama timed out — model may be overloaded. Please try again.")
    except requests.exceptions.ConnectionError:
        raise Exception("Cannot reach Ollama — make sure it is running.")

    if res.status_code != 200:
        raise Exception(f"Ollama error {res.status_code}: {res.text}")

    data = res.json()
    if "response" not in data:
        raise Exception(f"Unexpected Ollama response shape: {data}")

    # LLMs occasionally wrap output in whitespace or newlines; strip it.
    return data["response"].strip()
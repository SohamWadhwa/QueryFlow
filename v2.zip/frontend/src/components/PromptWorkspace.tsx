import { useState, useEffect } from "react";
import {
  SendHorizonal,
  Sparkles,
  Database,
  TableProperties,
  Code2,
  PanelLeftOpen,
  Check,
  X,
  Pencil,
  TerminalSquare,
  ChevronRight,
  Table2,
  Loader2,
} from "lucide-react";
import { QueryResultPanel, QueryResult } from "./QueryResultPanel";
import api from "@/lib/api";

interface PromptWorkspaceProps {
  sidebarCollapsed: boolean;
  onToggleSidebar: () => void;
  selectedDb: string | null;
}

interface SchemaColumn {
  name: string;
  type: string;
  primary_key: boolean;
  not_null: boolean;
  default_value: string | null;
  unique: boolean;
  foreign_key: { table: string; column: string } | null;
  constraints: string[];
}

interface SchemaTable {
  table: string;
  columns: SchemaColumn[];
}
type PreviewState = "idle" | "preview" | "editing" | "approved" | "denied";

export function PromptWorkspace({ sidebarCollapsed, onToggleSidebar, selectedDb }: PromptWorkspaceProps) {
  const [query, setQuery] = useState("");
  const [manualSql, setManualSql] = useState("");
  const [showManualSql, setShowManualSql] = useState(false);
  const [showSchema, setShowSchema] = useState(true);

  const [previewState, setPreviewState] = useState<PreviewState>("idle");
  const [generatedSql, setGeneratedSql] = useState("");
  const [editableSql, setEditableSql] = useState("");
  const [queryId, setQueryId] = useState<string | null>(null);
  const [queryResult, setQueryResult] = useState<QueryResult | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isApproving, setIsApproving] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Schema state
  const [schema, setSchema] = useState<SchemaTable[]>([]);
  const [schemaLoading, setSchemaLoading] = useState(false);
  const [schemaError, setSchemaError] = useState<string | null>(null);

  const suggestions = [
    { icon: TableProperties, text: "Show all tables in the database" },
    { icon: Code2, text: "Get total revenue by month" },
    { icon: Database, text: "Find top 10 customers by orders" },
    { icon: Sparkles, text: "Create a summary report" },
  ];

  // ─── Fetch schema whenever selectedDb changes ──────────────────────────────
  useEffect(() => {
    if (!selectedDb) {
      setSchema([]);
      return;
    }

    const fetchSchema = async () => {
      setSchemaLoading(true);
      setSchemaError(null);
      try {
        const res = await api.post("/db/schema", { db_name: selectedDb });
        setSchema(res.data.schema ?? []);
      } catch (err: any) {
        setSchemaError(err?.response?.data?.detail ?? "Failed to load schema.");
        setSchema([]);
      } finally {
        setSchemaLoading(false);
      }
    };

    fetchSchema();
  }, [selectedDb]);

  // ─── Generate SQL via NL prompt ────────────────────────────────────────────
  const handleSubmit = async () => {
    if (!query.trim() || !selectedDb) return;
    setSubmitError(null);
    setIsSubmitting(true);
    try {
      console.log("Submitting query:", query, "for database:", selectedDb);
      const res = await api.post("/query/generate", {
        db_name: selectedDb,
        user_query: query,
      });
      const { sql_query, query_id } = res.data;
      setGeneratedSql(sql_query);
      setEditableSql(sql_query);
      setQueryId(query_id);
      setPreviewState("preview");
      console.log("Generated SQL:", sql_query, "Query ID:", query_id);
    } catch (err: any) {
      setSubmitError(err?.response?.data?.detail ?? "Failed to generate SQL.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // ─── Approve pending query ─────────────────────────────────────────────────
  const handleApprove = async () => {
    if (!queryId) return;
    setIsApproving(true);
    setSubmitError(null);
    try {
      const res = await api.post(`/query/approve?query_id=${queryId}`);
      setQueryResult(parseResult(res.data.result, generatedSql));
      setPreviewState("approved");
    } catch (err: any) {
      setSubmitError(err?.response?.data?.detail ?? "Failed to approve query.");
    } finally {
      setIsApproving(false);
    }
  };

  // ─── Reject pending query ──────────────────────────────────────────────────
  const handleDeny = async () => {
    if (!queryId) return;
    try {
      await api.post(`/query/reject?query_id=${queryId}`);
    } catch {
      // best-effort; still clear UI
    }
    setPreviewState("denied");
    setTimeout(() => {
      setPreviewState("idle");
      setGeneratedSql("");
      setQueryId(null);
    }, 1200);
  };

  // ─── Enter edit mode ───────────────────────────────────────────────────────
  const handleEdit = () => {
    setEditableSql(generatedSql);
    setPreviewState("editing");
  };

  // ─── Save edited SQL to backend, then return to preview ───────────────────
  const handleSaveEdit = async () => {
    if (!queryId) return;
    try {
      await api.post(`/query/edit?query_id=${queryId}&new_sql=${encodeURIComponent(editableSql)}`);
      setGeneratedSql(editableSql);
      setPreviewState("preview");
    } catch (err: any) {
      setSubmitError(err?.response?.data?.detail ?? "Failed to save edit.");
    }
  };

  // ─── Run manual SQL via dedicated route (no LLM, no queue) ──────────────────
  const handleRunManualSql = async () => {
    if (!manualSql.trim() || !selectedDb) return;
    setSubmitError(null);
    setIsSubmitting(true);
    try {
      const res = await api.post("/query/run-manual", {
        db_name: selectedDb,
        sql: manualSql,
      });
      setQueryResult(parseResult(res.data.result, res.data.sql));
    } catch (err: any) {
      setSubmitError(err?.response?.data?.detail ?? "Failed to run manual SQL.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const showHero = previewState === "idle";
  const hasResult = queryResult !== null;

  // ─── Parse run_query output into QueryResult ───────────────────────────────
  // run_query returns: list-of-dicts for SELECT, {message} for writes
  const parseResult = (raw: any, sql: string): QueryResult => {
    if (Array.isArray(raw)) {
      const columns = raw.length > 0 ? Object.keys(raw[0]) : [];
      return {
        sql,
        columns,
        rows: raw,
        executedAt: new Date().toLocaleTimeString(),
        rowCount: raw.length,
        duration: "–",
      };
    }
    // Non-SELECT write result
    return {
      sql,
      columns: ["message"],
      rows: [{ message: raw?.message ?? "Query executed successfully" }],
      executedAt: new Date().toLocaleTimeString(),
      rowCount: 1,
      duration: "–",
    };
  };

  return (
    <main className="flex-1 flex flex-col h-screen bg-background overflow-hidden">
      {/* Top bar */}
      <header className="h-12 flex items-center px-4 border-b border-border justify-between flex-shrink-0">
        <div className="flex items-center">
          {sidebarCollapsed && (
            <button
              onClick={onToggleSidebar}
              className="p-1.5 rounded-md hover:bg-accent transition-colors mr-2"
            >
              <PanelLeftOpen className="h-4 w-4 text-muted-foreground" />
            </button>
          )}
          <span className="text-sm text-muted-foreground">NL-to-SQL Workspace</span>
        </div>
        <button
          onClick={() => setShowSchema((v) => !v)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            showSchema
              ? "bg-primary/10 text-primary"
              : "text-muted-foreground hover:bg-accent"
          }`}
        >
          <Table2 className="h-3.5 w-3.5" />
          Schema
        </button>
      </header>

      {/* Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Main area + Result panel wrapper */}
        <div className="flex-1 flex overflow-hidden transition-all duration-500 ease-in-out">
          {/* Input area */}
          <div
            className={`flex flex-col items-center overflow-y-auto px-6 py-8 transition-all duration-500 ease-in-out ${
              hasResult ? "w-1/2 flex-shrink-0" : "flex-1"
            }`}
          >
            <div className="w-full max-w-2xl flex flex-col items-center">
              {/* Hero - only when idle */}
              {showHero && (
                <>
                  <div className="text-center mb-10">
                    <div className="inline-flex items-center justify-center h-14 w-14 rounded-2xl bg-primary/10 mb-5">
                      <Sparkles className="h-7 w-7 text-primary" />
                    </div>
                    <h1 className="text-2xl font-semibold text-foreground mb-2">
                      Ask anything about your data
                    </h1>
                    <p className="text-muted-foreground text-sm max-w-md mx-auto">
                      Describe what you need in plain English and we'll generate the SQL query for you.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-8 w-full max-w-lg">
                    {suggestions.map((s, i) => (
                      <button
                        key={i}
                        onClick={() => setQuery(s.text)}
                        className="flex items-center gap-2.5 px-4 py-3 rounded-xl border border-border bg-card text-sm text-foreground hover:border-primary/30 hover:shadow-sm transition-all text-left"
                      >
                        <s.icon className="h-4 w-4 text-primary flex-shrink-0" />
                        <span className="line-clamp-1">{s.text}</span>
                      </button>
                    ))}
                  </div>
                </>
              )}

              {/* Prompt input */}
              <div className="w-full">
                <div className="relative rounded-2xl border border-prompt-border bg-prompt shadow-lg shadow-prompt-shadow/50">
                  <textarea
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSubmit();
                      }
                    }}
                    placeholder={
                      selectedDb
                        ? "Describe your query in plain English..."
                        : "Select a database first to generate queries."
                    }
                    disabled={!selectedDb || isSubmitting}
                    rows={3}
                    className="w-full resize-none rounded-2xl bg-transparent px-5 py-4 pr-14 text-sm text-foreground placeholder:text-muted-foreground outline-none disabled:opacity-50"
                  />
                  <button
                    onClick={handleSubmit}
                    disabled={!query.trim() || !selectedDb || isSubmitting}
                    className="absolute right-3 bottom-3 p-2.5 rounded-xl bg-primary text-primary-foreground disabled:opacity-30 hover:opacity-90 transition-all"
                  >
                    {isSubmitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <SendHorizonal className="h-4 w-4" />
                    )}
                  </button>
                </div>

                {/* Error message */}
                {submitError && (
                  <p className="mt-2 text-xs text-red-500">{submitError}</p>
                )}

                {/* Manual SQL toggle */}
                <div className="mt-3 flex items-center justify-between">
                  <button
                    onClick={() => setShowManualSql((v) => !v)}
                    className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <TerminalSquare className="h-3.5 w-3.5" />
                    Write SQL manually
                    <ChevronRight
                      className={`h-3 w-3 transition-transform ${showManualSql ? "rotate-90" : ""}`}
                    />
                  </button>
                  <p className="text-[11px] text-muted-foreground">
                    Verify generated SQL before running.
                  </p>
                </div>

                {/* Manual SQL input */}
                {showManualSql && (
                  <div className="mt-3 rounded-xl border border-border bg-card overflow-hidden">
                    <div className="px-4 py-2 border-b border-border bg-muted/50">
                      <span className="text-xs font-medium text-muted-foreground">Manual SQL</span>
                    </div>
                    <textarea
                      value={manualSql}
                      onChange={(e) => setManualSql(e.target.value)}
                      placeholder="SELECT * FROM ..."
                      rows={4}
                      className="w-full resize-none bg-transparent px-4 py-3 text-sm font-mono text-foreground placeholder:text-muted-foreground outline-none"
                    />
                    <div className="px-4 py-2 border-t border-border flex justify-end">
                      <button
                        onClick={handleRunManualSql}
                        disabled={!manualSql.trim() || !selectedDb || isSubmitting}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium disabled:opacity-30 hover:opacity-90 transition-all"
                      >
                        {isSubmitting ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          <Check className="h-3 w-3" />
                        )}
                        Run Query
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Query Preview Panel */}
              {previewState !== "idle" && (
                <div className="w-full mt-6 rounded-xl border border-border bg-card overflow-hidden shadow-sm animate-in fade-in slide-in-from-bottom-2 duration-300">
                  {/* Header */}
                  <div className="px-4 py-2.5 border-b border-border bg-muted/50 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Code2 className="h-4 w-4 text-primary" />
                      <span className="text-xs font-semibold text-foreground">Generated SQL</span>
                    </div>
                    {previewState === "approved" && (
                      <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                        ✓ Approved
                      </span>
                    )}
                    {previewState === "denied" && (
                      <span className="text-xs font-medium text-red-600 bg-red-50 px-2 py-0.5 rounded-full">
                        ✗ Denied
                      </span>
                    )}
                  </div>

                  {/* SQL body */}
                  <div className="px-4 py-3">
                    {previewState === "editing" ? (
                      <textarea
                        value={editableSql}
                        onChange={(e) => setEditableSql(e.target.value)}
                        rows={6}
                        className="w-full resize-none bg-muted/30 rounded-lg px-3 py-2.5 text-sm font-mono text-foreground outline-none focus:ring-1 focus:ring-primary/30 transition-all"
                      />
                    ) : (
                      <pre className="text-sm font-mono text-foreground whitespace-pre-wrap bg-muted/30 rounded-lg px-3 py-2.5 overflow-x-auto">
                        {generatedSql}
                      </pre>
                    )}
                  </div>

                  {/* Actions */}
                  {(previewState === "preview" || previewState === "editing") && (
                    <div className="px-4 py-2.5 border-t border-border flex items-center gap-2 justify-end">
                      {previewState === "editing" ? (
                        <>
                          <button
                            onClick={() => setPreviewState("preview")}
                            className="px-3 py-1.5 rounded-lg text-xs font-medium text-muted-foreground hover:bg-accent transition-colors"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={handleSaveEdit}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:opacity-90 transition-all"
                          >
                            <Check className="h-3 w-3" />
                            Save Changes
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            onClick={handleDeny}
                            disabled={isApproving}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-colors disabled:opacity-30"
                          >
                            <X className="h-3 w-3" />
                            Deny
                          </button>
                          <button
                            onClick={handleEdit}
                            disabled={isApproving}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:bg-accent transition-colors disabled:opacity-30"
                          >
                            <Pencil className="h-3 w-3" />
                            Edit
                          </button>
                          <button
                            onClick={handleApprove}
                            disabled={isApproving}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 text-primary-foreground text-xs font-medium hover:bg-emerald-700 transition-colors disabled:opacity-60"
                          >
                            {isApproving ? (
                              <Loader2 className="h-3 w-3 animate-spin" />
                            ) : (
                              <Check className="h-3 w-3" />
                            )}
                            Approve
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Result Panel */}
        <div
          className={`overflow-hidden transition-all duration-500 ease-in-out ${
            hasResult ? "w-1/2 opacity-100" : "w-0 opacity-0"
          }`}
        >
          {queryResult && (
            <QueryResultPanel
              result={queryResult}
              onClose={() => setQueryResult(null)}
            />
          )}
        </div>

        {/* Schema Panel */}
        {showSchema && (
          <aside className="w-80 border-l border-border bg-card overflow-y-auto flex-shrink-0 animate-in slide-in-from-right-4 duration-200">
            <div className="p-4 border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Database className="h-4 w-4 text-primary" />
                  <span className="text-sm font-semibold text-foreground">Database Schema</span>
                </div>
                <button
                  onClick={() => setShowSchema(false)}
                  className="p-1 rounded-md hover:bg-accent transition-colors"
                >
                  <X className="h-3.5 w-3.5 text-muted-foreground" />
                </button>
              </div>
              {!selectedDb && (
                <p className="text-xs text-muted-foreground mt-2">
                  Select a database from the sidebar to view its schema.
                </p>
              )}
            </div>

            {selectedDb && (
              <div className="p-3 space-y-3">
                {schemaLoading && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground px-1 py-2">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    Loading schema…
                  </div>
                )}

                {schemaError && (
                  <p className="text-xs text-red-500 px-1">{schemaError}</p>
                )}

                {!schemaLoading && !schemaError && schema.length === 0 && (
                  <p className="text-xs text-muted-foreground px-1">No tables found.</p>
                )}

                {!schemaLoading &&
                  schema.map((t) => (
                    <div key={t.table} className="rounded-lg border border-border overflow-hidden">
                      {/* Table header */}
                      <div className="px-3 py-2 bg-muted/50 border-b border-border flex items-center gap-1.5">
                        <Database className="h-3 w-3 text-primary flex-shrink-0" />
                        <span className="text-xs font-semibold text-foreground font-mono">{t.table}</span>
                        <span className="ml-auto text-[10px] text-muted-foreground">{t.columns.length} col{t.columns.length !== 1 ? "s" : ""}</span>
                      </div>

                      {/* Column rows */}
                      <div className="divide-y divide-border">
                        {t.columns.map((col) => (
                          <div key={col.name} className="px-3 py-2 hover:bg-muted/30 transition-colors">
                            {/* Row 1: icon + name + type */}
                            <div className="flex items-center gap-1.5 min-w-0">
                              {col.primary_key ? (
                                <span title="Primary Key" className="text-amber-500 flex-shrink-0 text-[11px]">🔑</span>
                              ) : col.foreign_key ? (
                                <span title={`FK → ${col.foreign_key.table}.${col.foreign_key.column}`} className="flex-shrink-0 text-[11px]">🔗</span>
                              ) : (
                                <span className="flex-shrink-0 w-4" />
                              )}
                              <span className="font-mono text-xs font-medium text-foreground truncate">{col.name}</span>
                              <span className="ml-auto font-mono text-[10px] text-primary/80 bg-primary/8 px-1.5 py-0.5 rounded flex-shrink-0">
                                {col.type}
                              </span>
                            </div>

                            {/* Row 2: constraint badges */}
                            {col.constraints.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-1.5 pl-5">
                                {col.primary_key && (
                                  <span className="text-[9px] font-medium px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                                    PK
                                  </span>
                                )}
                                {col.not_null && !col.primary_key && (
                                  <span className="text-[9px] font-medium px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                                    NOT NULL
                                  </span>
                                )}
                                {col.unique && (
                                  <span className="text-[9px] font-medium px-1.5 py-0.5 rounded-full bg-violet-50 text-violet-700 border border-violet-200">
                                    UNIQUE
                                  </span>
                                )}
                                {col.foreign_key && (
                                  <span className="text-[9px] font-medium px-1.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200" title={`References ${col.foreign_key.table}.${col.foreign_key.column}`}>
                                    FK → {col.foreign_key.table}
                                  </span>
                                )}
                                {col.default_value !== null && (
                                  <span className="text-[9px] font-medium px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                                    DEFAULT {col.default_value}
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </aside>
        )}
      </div>
    </main>
  );
}